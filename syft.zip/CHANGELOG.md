### Added Features

- --enrich flag for data enrichment feature enablement [[#3182](https://github.com/anchore/syft/pull/3182) @kzantow]
- Add classifier for Dart lang [[#3265](https://github.com/anchore/syft/pull/3265) @LaurentGoderre]
- add binary classifiers for lighttp, proftpd, zstd, xz, gzip, jq, and sqlcipher [[#3252](https://github.com/anchore/syft/pull/3252) @krysgor]
- Catalog JDKs more completely [[#3188](https://github.com/anchore/syft/issues/3188) [#3217](https://github.com/anchore/syft/pull/3217) @wagoodman]
- Show richer information for JVM installations [[#1426](https://github.com/anchore/syft/issues/1426) [#3217](https://github.com/anchore/syft/pull/3217) @wagoodman]
- Allow for stubbing unknown versions over dropping packages [[#2652](https://github.com/anchore/syft/issues/2652) [#3257](https://github.com/anchore/syft/pull/3257) @wagoodman]
- Name and Version empty for Java package when scanning provided image [[#2132](https://github.com/anchore/syft/issues/2132) [#3257](https://github.com/anchore/syft/pull/3257) @wagoodman]
- Support bitnami/mysql:8.x [[#3025](https://github.com/anchore/syft/issues/3025)]

### Bug Fixes

- OpenJDK CPEs [[#2422](https://github.com/anchore/syft/issues/2422) [#3217](https://github.com/anchore/syft/pull/3217) @wagoodman]
- SBOM generated from poetry lock file contains no license information on any dependencies [[#3204](https://github.com/anchore/syft/issues/3204)]
- Scanning a folder with a jar archive with no metadata creates a SPDX package without versionInfo (Non-NTIA compliant) [[#2039](https://github.com/anchore/syft/issues/2039) [#3257](https://github.com/anchore/syft/pull/3257) @wagoodman]
- Using replace in a go.mod creates a SPDX package without versionInfo (Non-NTIA compliant) [[#2038](https://github.com/anchore/syft/issues/2038) [#3257](https://github.com/anchore/syft/pull/3257) @wagoodman]
- Command `make add-snippet` can fail in some cases [[#3249](https://github.com/anchore/syft/issues/3249)]

**[(Full Changelog)](https://github.com/anchore/syft/compare/v1.12.2...v1.13.0)**
